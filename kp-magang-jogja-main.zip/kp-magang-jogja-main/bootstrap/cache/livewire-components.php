<?php return array (
  'attendance' => 'App\\Http\\Livewire\\Attendance',
  'create-admin' => 'App\\Http\\Livewire\\CreateAdmin',
  'create-apprentice' => 'App\\Http\\Livewire\\CreateApprentice',
  'create-progress-project' => 'App\\Http\\Livewire\\CreateProgressProject',
  'create-valuation' => 'App\\Http\\Livewire\\CreateValuation',
  'submission' => 'App\\Http\\Livewire\\Submission',
  'update-agency' => 'App\\Http\\Livewire\\UpdateAgency',
  'update-progress-project' => 'App\\Http\\Livewire\\UpdateProgressProject',
  'update-valuation' => 'App\\Http\\Livewire\\UpdateValuation',
);