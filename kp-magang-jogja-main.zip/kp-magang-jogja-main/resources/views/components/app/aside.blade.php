<!-- Desktop sidebar -->
<aside class="sidebar">
    <x-app._menus></x-app._menus>
</aside>
