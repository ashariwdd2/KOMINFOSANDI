<a {{ $attributes->merge(['class' => 'transition-colors duration-200 block px-4 py-2 text-normal hover:bg-opacity-25 hover:bg-teal-200 hover:text-teal-600']) }}>{{ $slot }}</a>
