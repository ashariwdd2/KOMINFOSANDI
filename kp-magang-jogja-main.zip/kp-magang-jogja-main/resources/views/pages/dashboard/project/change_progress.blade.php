<x-app-layout title="Project">
    <main class="main-card">    
        <livewire:update-progress-project :data="$progress" :id="$teamID">
    </main>
</x-app-layout>
