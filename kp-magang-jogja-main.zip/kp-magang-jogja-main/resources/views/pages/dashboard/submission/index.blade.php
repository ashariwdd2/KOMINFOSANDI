<x-app-layout title="Submission">
    <div>
        <h2 class="text-2xl font-semibold leading-tight">{{ __('List Submission') }}</h2>
    </div>
    <livewire:submission :submission="$submission">
</x-app-layout>