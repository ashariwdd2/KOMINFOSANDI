<?php if (isset($component)) { $__componentOriginalc3251b308c33b100480ddc8862d4f9c79f6df015 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\GuestLayout::class, ['title' => 'Pendaftaran Magang']); ?>
<?php $component->withName('guest-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
    <?php $__env->startSection('style'); ?>
        <script src="/assets/vendor/js/jquery.min.js"></script>
        <link href="/assets/vendor/css/select2.min.css" rel="stylesheet" />
        <script src="/assets/vendor/js/select2/select2.min.js"></script>
        <script src="/assets/vendor/js/select2/id.min.js"></script>
        <style>
            .hasImage:hover section {
                background-color: rgba(5, 5, 5, 0.4);
            }
            .hasImage:hover button:hover {
                background: rgba(5, 5, 5, 0.45);
            }

            #overlay p,
            i {
                opacity: 0;
            }

            #overlay.draggedover {
                background-color: rgba(255, 255, 255, 0.7);
            }
            #overlay.draggedover p,
            #overlay.draggedover i {
                opacity: 1;
            }

            .group:hover .group-hover\:text-blue-800 {
                color: #2b6cb0;
            }
    </style>
    <?php $__env->stopSection(); ?>

    <div class="banner justify-center py-16" style="background: url('/assets/img/hero-bg.png')">
        <div class="container max-w-screen-xl mx-auto items-center">
            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('create-apprentice')->html();
} elseif ($_instance->childHasBeenRendered('Dx5UNPt')) {
    $componentId = $_instance->getRenderedChildComponentId('Dx5UNPt');
    $componentTag = $_instance->getRenderedChildComponentTagName('Dx5UNPt');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('Dx5UNPt');
} else {
    $response = \Livewire\Livewire::mount('create-apprentice');
    $html = $response->html();
    $_instance->logRenderedChild('Dx5UNPt', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
        </div>
    </div>


    <?php $__env->startSection('scripts'); ?>
        <script>
            $("#selectAgency").select2({
                tags: false,
                language: "id"
            });
        </script>
        <script> Livewire.on('openTab', link => { alert('A post was added with the id of: ' + link); }) </script>
    <?php $__env->stopSection(); ?>
 <?php if (isset($__componentOriginalc3251b308c33b100480ddc8862d4f9c79f6df015)): ?>
<?php $component = $__componentOriginalc3251b308c33b100480ddc8862d4f9c79f6df015; ?>
<?php unset($__componentOriginalc3251b308c33b100480ddc8862d4f9c79f6df015); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\kp-magang-jogja-main\resources\views/pages/guest/registration.blade.php ENDPATH**/ ?>