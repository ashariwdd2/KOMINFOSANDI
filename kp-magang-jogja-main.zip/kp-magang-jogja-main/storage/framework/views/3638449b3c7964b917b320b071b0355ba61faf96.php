<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title><?php echo e($title); ?></title>
        
        <link rel="shortcut icon" href="favico.ico">
        <link rel="stylesheet" href="<?php echo e(mix('/assets/css/guest.css')); ?>">
        <link rel="stylesheet" href="/assets/vendor/css/aos.min.css" />
        <link rel="stylesheet" href="/assets/vendor/css/bootstrap-icons.min.css" />
        <link rel="stylesheet" href="/assets/vendor/js/jquery.min.js" />
        <script src="<?php echo e(mix('/assets/js/guest.js')); ?>" defer></script>
        <?php echo \Livewire\Livewire::styles(); ?>

        <?php echo $__env->yieldContent('style'); ?>
    </head>
    <body>
        <div class="flex flex-col h-screen">
            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.guest.navbar','data' => []]); ?>
<?php $component->withName('guest.navbar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
            
            <div class="flex-1 pt-16">
                <?php echo e($slot); ?>

            </div>
            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.guest.footer','data' => []]); ?>
<?php $component->withName('guest.footer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
        </div>
        <?php echo \Livewire\Livewire::scripts(); ?>

        <?php echo $__env->yieldPushContent('scripts'); ?>
        <?php echo $__env->yieldContent('scripts'); ?>
        <script src="/assets/vendor/js/aos.min.js"></script>
        <script>
            AOS.init();
        </script>
    </body>
</html><?php /**PATH C:\xampp\htdocs\kp-magang-jogja-main\resources\views/layouts/guest.blade.php ENDPATH**/ ?>