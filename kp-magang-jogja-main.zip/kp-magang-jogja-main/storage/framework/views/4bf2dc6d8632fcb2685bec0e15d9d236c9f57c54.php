<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, ['title' => 'Detail Progress']); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
    <div class="mt-4 mb-4">
        <h1 class="font-semibold text-gray-700 text-lg"><?php echo e($team->project->name_project); ?></h1>
        <span><?php echo e($progress->name); ?></span>
    </div>

    <main class="main-card">
        <?php if(\Auth::user()->adminDetail): ?>
            <?php if($progress->status == "SELESAI"): ?>
                <?php if(isset($progress->valuation->score)): ?>
                    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('update-valuation', ['valuation' => $progress->valuation,'id' => $team->project->id])->html();
} elseif ($_instance->childHasBeenRendered('MSvAER5')) {
    $componentId = $_instance->getRenderedChildComponentId('MSvAER5');
    $componentTag = $_instance->getRenderedChildComponentTagName('MSvAER5');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('MSvAER5');
} else {
    $response = \Livewire\Livewire::mount('update-valuation', ['valuation' => $progress->valuation,'id' => $team->project->id]);
    $html = $response->html();
    $_instance->logRenderedChild('MSvAER5', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                <?php else: ?>
                    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('create-valuation', ['id' => $team->project->id,'teamid' => $team->id,'progress' => $progress])->html();
} elseif ($_instance->childHasBeenRendered('Aa06Qj4')) {
    $componentId = $_instance->getRenderedChildComponentId('Aa06Qj4');
    $componentTag = $_instance->getRenderedChildComponentTagName('Aa06Qj4');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('Aa06Qj4');
} else {
    $response = \Livewire\Livewire::mount('create-valuation', ['id' => $team->project->id,'teamid' => $team->id,'progress' => $progress]);
    $html = $response->html();
    $_instance->logRenderedChild('Aa06Qj4', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                <?php endif; ?>
            <?php endif; ?>
        <?php endif; ?>
        <div class="grid grid-cols-6">
            <div class="col-span-6 sm:col-span-1 border-l sm:border-b-0 border-r sm:border-t bg-gray-100 p-2 border border-gray-300">
                <span>Penanggung Jawab</span>
            </div>
            <div class="col-span-6 sm:col-span-5 p-2 border-l sm:border-l-0 border-r sm:border-t border-gray-300">
                <span><?php echo e($progress->jss[0]->fullname); ?></span>
            </div>

            <div class="col-span-6 sm:col-span-1 border-l sm:border-b-0 border-r sm:border-t border-b-0 bg-gray-100 p-2 border border-gray-300">
                <span>Status</span>
            </div>
            <div class="col-span-6 sm:col-span-5 border-l sm:border-l-0 sm:border-b-0 border-b-0 border-r sm:border-t p-2 border border-gray-300">
                <span><?php echo e($progress->status); ?></span>
            </div>

            <div class="col-span-6 sm:col-span-1 border-l sm:border-b-0 border-r sm:border-t border-b-0 bg-gray-100 p-2 border border-gray-300">
                <span>Penjelasan</span>
            </div>
            <div class="col-span-6 sm:col-span-5 border-l sm:border-b-0 sm:border-l-0 border-r sm:border-t p-2 border-b-0 border border-gray-300">
                <span><?php echo e($progress->explanation); ?></span>
            </div>

            <div class="col-span-6 sm:col-span-1 bg-gray-100 p-2 border border-gray-300 border-b-0 sm:border-b">
                <span>Nilai</span>
            </div>
            <div class="col-span-6 sm:col-span-5 border-l sm:border-l-0 border-r sm:border-t p-2 border border-gray-300">
                <span>
                    <?php if(isset($progress->valuation->score)): ?>
                        <?php echo e($progress->valuation->score); ?>

                    <?php else: ?>
                        BELUM DINILAI
                    <?php endif; ?>
                </span>
            </div>
        </div>
    </main>
    <div class="main-card mt-6">
        <h1 class="font-semibold text-gray-700 mb-3 text-lg">File</h1>
        <img src="https://images.unsplash.com/photo-1581291518857-4e27b48ff24e?ixid=MnwxMjA3fDF8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80" class="w-full"/>
        
    </div>
 <?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\kp-magang-jogja-main\resources\views/pages/dashboard/project/detail_progress_project.blade.php ENDPATH**/ ?>