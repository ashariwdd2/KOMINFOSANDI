<?php if (isset($component)) { $__componentOriginalc3251b308c33b100480ddc8862d4f9c79f6df015 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\GuestLayout::class, ['title' => 'Pendaftaran Magang']); ?>
<?php $component->withName('guest-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
    <div id="banner" style="background: url('/assets/img/hero-bg.png');">
        <div class="banner-body">
            <div data-aos="fade-up" class="order-last lg:order-first mx-4 mt-4 lg:m-0">
                <h1 style="color: #364146">Pendaftaran Magang</h1>
                <h2 style="color: #576971">Dinas Komunikasi, Informatika dan Persandian Kota Yogyakarta</h2>
                <a href="<?php echo e(route("pendaftaran-magang")); ?>" class="getting-starter">Daftar Sekarang</a>
            </div>
            <div data-aos="fade-left" class="order-first lg:order-last">
                <img class="logo" src="/assets/img/logo.webp"/>
            </div>
        </div>
    </div>

    <main>
        <div class="border border-gray-300 rounded-md" style="max-width: 395px;">
            <img class="w-full" src="/assets/img/1.png"/>
            <div class="p-4">
                <h3 class="uppercase">daftar magang</h3>
                <p>Halaman pendaftaran magang mahasiswa pada instansi di seluruh Kota Yogyakarta.</p>
            </div>
            <div class="bg-gray-300 p-3 w-full flex">
                <a href="#" class="btn-card">daftar</a>
            </div>
        </div>
        <div class="border border-gray-300 rounded-md" style="max-width: 395px;">
            <img class="w-full" src="/assets/img/1.png"/>
            <div class="p-4">
                <h3 class="uppercase">daftar magang</h3>
                <p>Halaman pendaftaran magang mahasiswa pada instansi di seluruh Kota Yogyakarta.</p>
            </div>
            <div class="bg-gray-300 p-3 w-full flex">
                <a href="#" class="btn-card">daftar</a>
            </div>
        </div>
        <div class="border border-gray-300 rounded-md" style="max-width: 395px;">
            <img class="w-full" src="/assets/img/1.png"/>
            <div class="p-4">
                <h3 class="uppercase">daftar magang</h3>
                <p>Halaman pendaftaran magang mahasiswa pada instansi di seluruh Kota Yogyakarta.</p>
            </div>
            <div class="bg-gray-300 p-3 w-full flex">
                <a href="#" class="btn-card">daftar</a>
            </div>
        </div>
    </main>
 <?php if (isset($__componentOriginalc3251b308c33b100480ddc8862d4f9c79f6df015)): ?>
<?php $component = $__componentOriginalc3251b308c33b100480ddc8862d4f9c79f6df015; ?>
<?php unset($__componentOriginalc3251b308c33b100480ddc8862d4f9c79f6df015); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\kp-magang-jogja-main\resources\views/pages/guest/index.blade.php ENDPATH**/ ?>